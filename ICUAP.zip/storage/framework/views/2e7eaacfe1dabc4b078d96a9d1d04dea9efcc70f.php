<div>
    <div id="validarErrores">
        <div class="bg-green-400 text-white my-2 rounded-lg text-sm p2 text-center">
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    <form wire:submit.prevent="submit" method="POST">

        <div class="mb-2">
            <label for="user" class="mb-2 block uppercase text-gray-500 font-bold">Usuario</label>
            <input id="user" wire:model='usuario' name="user" type="text" placeholder="Tu nombre de usuario"
                class="border w-full p-2 rounded-lg ">
            <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2">
            <label for="password" class="mb-2 block uppercase text-gray-500 font-bold">Password</label>
            <input id="password" wire:model='password' name="password" type="password"
                placeholder="Tu password de registro" class="border w-full p-2 rounded-lg ">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-2">
            <label for="password_confirmation" class="mb-2 block uppercase text-gray-500 font-bold">Repetir
                password</label>
            <input id="password_confirmation" wire:model='password_confirmation' name="password_confirmation"
                type="password" placeholder="Repite tu password" class="border w-full p-2 rounded-lg ">
                
        </div>
        
        <div class="mb-3">
            <label for="tipo_user" class="mb-2 block uppercase text-gray-500 font-bold">Tipo de usuario</label>
            <select id="tipo_user" wire:model='tipoUser' class="border w-full p-2 rounded-lg bg-white">
                <option selected="0">Elija un usuario</option>
                <option value="1">Administrador</option>
                <option value="2">Capturista</option>
            </select>
            <?php $__errorArgs = ['tipoUser'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <input type="submit" id="btnAltaUser" value="Crear Cuenta"
            class="bg-[#003B5C] font-bold w-100 p-3 text-white rounded-lg mt-2" />
    </form>

</div>
<?php /**PATH /var/www/html/resources/views/livewire/modal-users-sistema.blade.php ENDPATH**/ ?>