<div>
    <form class="flex items-center md:w-1/2 mx-auto mt-4">
        <div class="relative w-full">
            <input type="text" wire:model="buscar" id="apellido" wire:keydown.backspace="reoverInvestigadorSeleccionado"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full pl-10 p-2.5 dark:border-gray-600 dark:placeholder-gray-400"
                placeholder="Ingresa el Nombre para hacer la busqueda">
            <?php $__errorArgs = ['buscar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="input-group mb3"> <span
                        class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="">
                <?php if(!$piecked): ?>
                    <?php $__currentLoopData = $investigadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inves): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div style="cursor: pointer;">
                            <a
                                wire:click="asignarInvestigador('<?php echo e($inves->id); ?>','<?php echo e($inves->nombres); ?> <?php echo e($inves->apellido_paterno); ?> <?php echo e($inves->apellido_materno); ?>')">
                                <?php echo e($inves->nombres); ?> <?php echo e($inves->apellido_paterno); ?> <?php echo e($inves->apellido_materno); ?>

                            </a>
                        </div>
                        </br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </form>
    <?php if($piecked): ?>
        <div id="root">
            <div class="border-b border-gray-200 dark:border-gray-700 md:w-1/2 mx-auto mt-9">
                <ul class="flex flex-wrap -mb-px text-sm font-medium text-center">
                    <li class="mr-2">
                        <a href="#" wire:click='clickPatente'
                            class="inline-flex p-4 rounded-t-lg border-b-2 border-transparent">
                            <i class="mr-2 w-5 h-5 bi bi-patch-check-fill"></i> Patentes</a>
                    </li>
                    <li class="mr-2">
                        <a href="#" wire:click='clickArti' class="inline-flex p-4" aria-current="page">
                            <i class="mr-2 w-5 h-5 bi bi-file-text-fill"></i>Articulos </a>
                    </li>
                    <li class="mr-2">
                        <a href="#" wire:click='clickRed' class="inline-flex p-4"><i
                                class="mr-2 w-5 h-5 bi bi-globe2"></i>Redes
                            Institucionales </a>
                    </li>
                </ul>
            </div>
            
            <div class="container mx-auto mt-20">
                <?php if($patenteSelected): ?>
                    <h1 class="font-black text-5xl text-center md:w-2/3 mx-auto">Ingresar Patentes de
                        <?php echo e($buscar); ?></h1>
                    <div class="mt-12 md:flex">
                        <div class="md:w-1/2 lg:w-2/5 mx-5">
                            <h2 class="font-black text-3xl text-center">Ingresar Patentes</h2>
                            <p class="text-lg mt-5 text-center mb-10">Añade Patentes y <span>Administrarlos</span></p>
                            <form class="bg-white shadow-lg rounded-lg py-10 px-10"
                                wire:submit.prevent='AgregarPatente'>
                                <div class="bg-green-400 text-white my-2 rounded-lg text-sm p2 text-center">
                                    <?php if(session()->has('message')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session('message')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-5"><label for="patente"
                                        class="block text-gray-700 uppercase font-bold">Nombre Patente </label>
                                    <input id="patente" wire:model='pNombre' type="text"
                                        placeholder="Nombre de la patente"
                                        class="border-2 w-full p-2 mt-2 placeholder-gray-400 rounded-md">
                                    <div>
                                        <?php $__errorArgs = ['pNombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="input-group mb3"> <span
                                                    class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="mb-5">
                                    <label for="alta" class="block text-gray-700 uppercase font-bold">Alta</label>
                                    <input id="alta" type="date" wire:model='pFecha'
                                        class="border-2 w-full p-2 mt-2 placeholder-gray-400 rounded-md">
                                    <div>
                                        <?php $__errorArgs = ['pFecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="input-group mb3"> <span
                                                    class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="mb-5">
                                    <label for="Sintomas" class="block text-gray-700 uppercase font-bold">Resumen de la
                                        patente</label>
                                    <textarea id="resumen" wire:model='pResume' class="border-2 w-full p-2 mt-2 placeholder-gray-400 rounded-md"
                                        placeholder="Resumen de patente"></textarea>
                                    <div>
                                        <?php $__errorArgs = ['pResume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="input-group mb3"> <span
                                                    class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <?php if($editarp): ?>
                                    <input type="submit"
                                        class=" bg-[#003B5C] w-full p-3 text-white uppercase font-bold hover:bg-[#236082] cursor-pointer"
                                        value="Editar patente">
                                <?php else: ?>
                                    <input type="submit"
                                        class=" bg-[#003B5C] w-full p-3 text-white uppercase font-bold hover:bg-[#236082] cursor-pointer"
                                        value="Agregar patente">
                                <?php endif; ?>

                            </form>
                        </div>
                        <div class="md:w-1/2 lg:w-3/5 md:h-screen overflow-y-scroll">
                            <?php if(count($patentes) > 0): ?>
                                <?php $__currentLoopData = $patentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="max-w-3xl rounded overflow-hidden shadow-lg">
                                        <div class="px-6 py-4">
                                            <div class="font-bold text-xl mb-2"><?php echo e($patente->titulo); ?></div>

                                            <a class="decoration-solid">Fecha</a>
                                            <a><?php echo e($patente->year); ?></a>
                                            </br>
                                            <a class="decoration-solid">Resumen</a>
                                            <p><?php echo e($patente->resumen); ?></p>
                                        </div>
                                        <div class="flex justify-end">

                                            <button type="button" wire:click="eliminarPatente('<?php echo e($patente->id); ?>')"
                                                class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-white focus:outline-none bg-[#b9372d] rounded-full">Eliminar</button>

                                            <button type="button"
                                                wire:click="editarPatente('<?php echo e($patente->id); ?>','<?php echo e($patente->titulo); ?>','<?php echo e($patente->year); ?>','<?php echo e($patente->resumen); ?>')"
                                                class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-white focus:outline-none bg-[#003B5C] rounded-full ">Editar</button>
                                        </div>
                                    </div>
                                    <div id="relleno"></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <h2 class="font-black text-3xl text-center">No hay patentes registradas</h2>
                                <p class="text-xl mt-5 mb-10 text-center">comienza agregando una patente <span>y
                                        aparecerán
                                        en
                                        este lugar</span></p>
                            <?php endif; ?>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>


        <div class="container mx-auto mt-20">
            <?php if($articuloSelected): ?>
                <h1 class="font-black text-5xl text-center md:w-2/3 mx-auto">Ingresar Artículos de
                    <?php echo e($buscar); ?></h1>
                <div class="mt-12 md:flex">
                    <div class="md:w-1/2 lg:w-2/5 mx-5">
                        <h2 class="font-black text-3xl text-center">Ingresar Articulos</h2>
                        <p class="text-lg mt-5 text-center mb-10">Añade Artículos y <span>Administralos</span></p>
                        <form class="bg-white shadow-lg rounded-lg py-10 px-10" wire:submit.prevent='agregarArticulo'>
                            <div class="bg-green-400 text-white my-2 rounded-lg text-sm p2 text-center">
                                <?php if(session()->has('message')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('message')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="mb-4"><label for="patente"
                                    class="block text-gray-700 uppercase font-bold">Titulo de artículo</label>
                                <input type="text" placeholder="Titulo del artículo" wire:model='tituloArt'
                                    class="border-2 w-full p-2 mt-2 placeholder-gray-400 rounded-md">
                                <div>
                                    <?php $__errorArgs = ['tituloArt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="input-group mb3"> <span
                                                class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label for="alta" class="block text-gray-700 uppercase font-bold">Autores</label>
                                <input type="text" placeholder="Nombres separador por comas" wire:model='autoresA'
                                    class="border-2 w-full p-2 mt-2 placeholder-gray-400 rounded-md">
                                <div>
                                    <?php $__errorArgs = ['autoresA'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="input-group mb3"> <span
                                                class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label for="Sintomas" class="block text-gray-700 uppercase font-bold">Año de
                                    publicación</label>
                                <input id="alta" type="number" placeholder="1995" wire:model='fechaArt'
                                    class="border-2 w-full p-2 mt-2 placeholder-gray-400 rounded-md">
                                <div>
                                    <?php $__errorArgs = ['fechaArt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="input-group mb3"> <span
                                                class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label  class="block text-gray-700 uppercase font-bold">Doi</label>
                                <input  type="text" placeholder="10.1127/g.gphotochem.2022.123453" wire:model='doiArt'
                                    class="border-2 w-full p-2 mt-2 placeholder-gray-400 rounded-md">
                                <div>
                                    <?php $__errorArgs = ['doiArt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="input-group mb3"> <span
                                                class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label for="Sintomas" class="block text-gray-700 uppercase font-bold">Título de la
                                    revista</label>
                                <input id="alta" type="text" placeholder="Crystals" wire:model='journalArt'
                                    class="border-2 w-full p-2 mt-2 placeholder-gray-400 rounded-md">
                                <div>
                                    <?php $__errorArgs = ['journalArt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="input-group mb3"> <span
                                                class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <?php if($editarArticulo): ?>
                                <input type="submit"
                                    class=" bg-[#003B5C] w-full p-3 text-white uppercase font-bold hover:bg-[#236082] cursor-pointer"
                                    value="Editar artículo">
                            <?php else: ?>
                                <input type="submit"
                                    class=" bg-[#003B5C] w-full p-3 text-white uppercase font-bold hover:bg-[#236082] cursor-pointer"
                                    value="Agregar artículo">
                            <?php endif; ?>
                        </form>
                    </div>
                    <div class="md:w-1/2 lg:w-3/5 md:h-screen overflow-y-scroll">
                        <?php if(count($articulos) > 0): ?>
                            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="max-w-3xl rounded overflow-hidden shadow-lg">
                                    <div class="px-6 py-4">
                                        <div class="font-bold text-xl mb-2"><?php echo e($articulo->nombre); ?></div>

                                        <a class="decoration-solid">Año de publicacion</a>
                                        <a><?php echo e($articulo->ano_publicacion); ?></a>
                                        </br>
                                        <a class="decoration-solid">Doi</a>
                                        <p><?php echo e($articulo->doi); ?></p>
                                        <a class="decoration-solid">Autores</a>
                                        <p><?php echo e($articulo->autores); ?></p>
                                        <a class="decoration-solid">Revista</a>
                                        <p><?php echo e($this->getJournal($articulo->journal_id)); ?></p>
                                    </div>
                                    <div class="flex justify-end">

                                        <button type="button" wire:click="eliminarArticulo('<?php echo e($articulo->id); ?>')"
                                            class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-white focus:outline-none bg-[#b9372d] rounded-full">Eliminar</button>

                                        <button type="button"
                                            wire:click="editarArticulo('<?php echo e($articulo->id); ?>','<?php echo e($articulo->nombre); ?>','<?php echo e($articulo->ano_publicacion); ?>','<?php echo e($articulo->doi); ?>','<?php echo e($articulo->autores); ?>','<?php echo e($articulo->journal_id); ?>','<?php echo e($this->getJournal($articulo->journal_id)); ?>')"
                                            class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-white focus:outline-none bg-[#003B5C] rounded-full ">Editar</button>
                                    </div>
                                </div>
                                <div id="relleno"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h2 class="font-black text-3xl text-center">No hay artículos registrados</h2>
                            <p class="text-xl mt-5 mb-10 text-center">comienza agregando una artículo <span>y
                                    aparecerán
                                    en
                                    este lugar</span></p>
                        <?php endif; ?>


                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if($redSelected): ?>
            <div class="container mx-auto mt-20">

                <h1 class="font-black text-5xl text-center md:w-2/3 mx-auto">Ingresar Redes Institucionales de
                    <?php echo e($buscar); ?></h1>
                <div class="mt-12 md:flex">
                    <div class="md:w-1/2 lg:w-2/5 mx-5">
                        <h2 class="font-black text-3xl text-center">Ingresar Redes Institucionales</h2>
                        <p class="text-lg mt-5 text-center mb-10">Añade Redes Institucionales y
                            <span>Administralas</span>
                        </p>
                        <form class="bg-white shadow-lg rounded-lg py-10 px-10" wire:submit.prevent='AgregarRedes'>
                            <div class="bg-green-400 text-white my-2 rounded-lg text-sm p2 text-center">
                                <?php if(session()->has('message')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('message')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="mb-4"><label for=""
                                    class="block text-gray-700 uppercase font-bold">Tipo
                                    de red institucional </label>
                                <select id="tipo_red" wire:model='tipoR'
                                    class="bg-white border-2 w-full p-2 mt-2 placeholder-gray-400 rounded-md">
                                    <option selected>Elige el tipo de red</option>
                                    <option value="1">Nacional</option>
                                    <option value="2">Internacional</option>
                                </select>
                                <div>
                                    <?php $__errorArgs = ['tipoR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="input-group mb3"> <span
                                                class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label for="alta" class="block text-gray-700 uppercase font-bold">Nombre del
                                    centro</label>
                                <input id="alta" type="text" wire:model="nombreR"
                                    placeholder="Facultad de Ciencias Químicas, Benemérita Universidad Autónoma de Puebla (BUAP)"
                                    class="border-2 w-full p-2 mt-2 placeholder-gray-400 rounded-md">
                                <div>
                                    <?php $__errorArgs = ['nombreR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="input-group mb3"> <span
                                                class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <?php if($editarRed): ?>
                                <input type="submit"
                                    class=" bg-[#003B5C] w-full p-3 text-white uppercase font-bold hover:bg-[#236082] cursor-pointer"
                                    value="Editar Red">
                            <?php else: ?>
                                <input type="submit"
                                    class=" bg-[#003B5C] w-full p-3 text-white uppercase font-bold hover:bg-[#236082] cursor-pointer"
                                    value="Agregar Red">
                            <?php endif; ?>

                        </form>
                    </div>
                    <div class="md:w-1/2 lg:w-3/5 md:h-screen overflow-y-scroll">
                        <?php if(count($redes) > 0): ?>
                            <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="max-w-3xl rounded overflow-hidden shadow-lg">
                                    <div class="px-6 py-4">
                                        <div class="font-bold text-xl mb-2"><?php echo e($red->nombre); ?></div>

                                        <a class="decoration-solid">Tipo de red</a>
                                        <?php if($red->tipo_red_institucion_id ==1): ?>
                                            <a>Nacional</a>
                                            <?php else: ?>
                                            <a>Internacional</a>
                                        <?php endif; ?>
                                        
                                        </br>

                                    </div>
                                    <div class="flex justify-end">

                                        <button type="button" wire:click="eliminarRed('<?php echo e($red->id); ?>')"
                                            class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-white focus:outline-none bg-[#b9372d] rounded-full">Eliminar</button>

                                        <button type="button"
                                            wire:click="editarRed('<?php echo e($red->id); ?>','<?php echo e($red->nombre); ?>','<?php echo e($red->tipo_red_institucion_id); ?>')"
                                            class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-white focus:outline-none bg-[#003B5C] rounded-full ">Editar</button>
                                    </div>
                                </div>
                                <div id="relleno"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h2 class="font-black text-3xl text-center">No hay patentes registradas</h2>
                            <p class="text-xl mt-5 mb-10 text-center">comienza agregando una patente <span>y
                                    aparecerán
                                    en
                                    este lugar</span></p>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>


</div>
<?php /**PATH /var/www/html/resources/views/livewire/buscador-agregar-items.blade.php ENDPATH**/ ?>