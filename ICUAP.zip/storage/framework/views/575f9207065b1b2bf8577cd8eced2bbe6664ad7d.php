
    <div class="mt-12 md:flex">
        <div class="md:w-1/2 lg:w-2/5 mx-5">
            <div id="validarErrores">
                <div class="bg-green-400 text-white my-2 rounded-lg text-sm p2 text-center">
                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <h2 class="font-black text-3xl text-center">Editar usuarios</h2>
            <form wire:submit.prevent="submit" method="POST" class="bg-white shadow-md rounded-lg py-10 px-5">
                <div class="mb-4">
                    <label for="user" class="mb-2 block uppercase text-gray-500 font-bold">Usuario</label>
                    <input id="user" wire:model='usuario' name="user" type="text"
                        placeholder="Tu nombre de usuario" class="border w-full p-2 rounded-lg " disabled>
                    <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="bg-[#00B8E4] text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label for="tipo_user" class="mb-2 block uppercase text-gray-500 font-bold">Tipo de
                        usuario</label>
                    <select id="tipo_user" wire:model='tipoUser' class="border w-full p-2 rounded-lg bg-white">
                        <option selected="0">Elija un usuario</option>
                        <option value="1">Administrador</option>
                        <option value="2">Capturista</option>
                    </select>
                    <?php $__errorArgs = ['tipoUser'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="bg-[#00B8E4] text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4">
                    <label><input type="checkbox" wire:model="actualizarP" value="true">Actualizar Contraseña</label>
                </div>
                <?php if($actualizarP): ?>
                    <div class="mb-2">
                    <label for="password" class="mb-2 block uppercase text-gray-500 font-bold">Password</label>
                    <input id="password" wire:model='password' name="password" type="password"
                        placeholder="Tu password de registro" class="border w-full p-2 rounded-lg ">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="bg-[#00B8E4] text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4">
                    <label for="password_confirmation" class="mb-2 block uppercase text-gray-500 font-bold">Repetir
                        password</label>
                    <input id="password_confirmation" wire:model='password_confirmation'
                        name="password_confirmation" type="password" placeholder="Repite tu password"
                        class="border w-full p-2 rounded-lg ">
                </div>
                <?php endif; ?>
                <input type="submit" id="editarUsuario" value="Editar Cuenta"
                    class="bg-[#003B5C] font-bold w-100 p-3 text-white rounded-lg mt-2" />
            </form>
        </div>
        <div class="md:w-1/2 lg:w-3/5 md:h-screen overflow-y-scroll">
            
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mx-5 my-5 bg-white shadow-md px-5 py-3 rounded-xl">
                    <div class="px-6 py-4">
                        <?php if($usuario->tipo_user == 1): ?>
                            <div class="font-bold text-xl mb-2">Administrador</div>
                        <?php else: ?>
                            <div class="font-bold text-xl mb-2">Capturista</div>
                        <?php endif; ?>

                        <a class="decoration-solid">Usuario</a>
                        <a><?php echo e($usuario->user); ?></a>

                    </div>
                    <div class="flex justify-end">

                        <button type="button"
                            class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-white focus:outline-none bg-[#00B8E4] rounded-full"
                            wire:click="borrarUsuario('<?php echo e($usuario->id); ?>')">Eliminar</button>

                        <button type="button"
                            class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-white focus:outline-none bg-[#003B5C] rounded-full"
                            wire:click="editarUsuario('<?php echo e($usuario->user); ?>','<?php echo e($usuario->tipo_user); ?>','<?php echo e($usuario->id); ?>')">Editar</button>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php /**PATH /var/www/html/resources/views/livewire/listar-usuarios.blade.php ENDPATH**/ ?>