
<?php $__env->startSection('contenido'); ?>

<section class="contenedor">
    <div class='dashboard'>
        <div class="dashboard-nav">
            <nav class="dashboard-nav-list"><a href="#" class="dashboard-nav-item"><i
                        class="bi bi-house-door-fill"></i>Inicio </a>
                <a href="#" class="dashboard-nav-item active" data-bs-toggle="modal"
                    data-bs-target="#exampleModal"><i class="bi bi-person-fill-add"></i>Nuevo investigador</a>
                <a href="<?php echo e(route('investigadores')); ?>" class="dashboard-nav-item"><i class="bi bi-person-dash-fill"></i>Eliminar investigador</a>
                <a href="<?php echo e(route('completarInvestigador')); ?>" class="dashboard-nav-item"><i class="bi bi-person-fill-exclamation"></i>Completar investigador</a>
                <?php if(Auth::user()->tipo_user ==1): ?>
                    <a href="#" class="dashboard-nav-item active" data-bs-toggle="modal" 
                data-bs-target="#registrarUsuario"><i class="bi bi-person-fill-add"></i>Nuevo usuario</a>
                <a href="<?php echo e(route('listaUsuarios')); ?>" class="dashboard-nav-item"><i class="bi bi-gear-fill"></i>Lista usuarios </a>
                <?php endif; ?>
                

                
                <div class="nav-item-divider"></div>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit">
                        <a class="dashboard-nav-item"><i class="bi bi-box-arrow-right"></i> Cerrar sesión </a>
                    </button>
                    
                </form>
                
            </nav>
        </div>
        <div class='dashboard-app'>
            <div class='dashboard-content'>
                <div class='contenedor'>
                    <div class='card'>
                        <div class='card-header'>
                            <img class="logo-card" src="img/escudo_logotipo_buap_page-0001.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
    <!-- Modal -->
    <div class="modal fade bd-example-modal-lg" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <label for="tipo_user" class="mb-2 block uppercase text-gray-500 font-bold pd:none">alta investigador</label>
                    <button type="button" data-bs-dismiss="modal" aria-label="Close">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </button>
                </div>
                <div class="modal-body">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <!--Nav tab-->
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="datos-user" data-bs-toggle="tab" data-bs-target="#data"
                                type="button" role="tab" aria-controls="data" aria-selected="true">Datos</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal-add-user', [])->html();
} elseif ($_instance->childHasBeenRendered('LT6nAJq')) {
    $componentId = $_instance->getRenderedChildComponentId('LT6nAJq');
    $componentTag = $_instance->getRenderedChildComponentTagName('LT6nAJq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LT6nAJq');
} else {
    $response = \Livewire\Livewire::mount('modal-add-user', []);
    $html = $response->html();
    $_instance->logRenderedChild('LT6nAJq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div><!-- Fin modal body -->
                
            
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade bd-example-modal-lg" id="registrarUsuario" tabindex="-1" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <label for="tipo_user" class="mb-2 block uppercase text-gray-500 font-bold pd:none">alta usuario</label>
                    <button type="button" data-bs-dismiss="modal" aria-label="Close">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </button>
                </div>
                <div class="modal-body">
                   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal-users-sistema', [])->html();
} elseif ($_instance->childHasBeenRendered('39eZLEM')) {
    $componentId = $_instance->getRenderedChildComponentId('39eZLEM');
    $componentTag = $_instance->getRenderedChildComponentTagName('39eZLEM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('39eZLEM');
} else {
    $response = \Livewire\Livewire::mount('modal-users-sistema', []);
    $html = $response->html();
    $_instance->logRenderedChild('39eZLEM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div><!-- Fin modal body -->
               
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/auth/menuAdministracion.blade.php ENDPATH**/ ?>