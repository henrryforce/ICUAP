

<?php $__env->startSection('contenido'); ?>
<h1 class="font-black text-3xl text-center pt-9">Completar la información del investigador</h1>
<p class="text-center text-lg mt-4">Ingresa el apellido del investigador <br> y selecciona una opción</p>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('buscador-agregar-items', [])->html();
} elseif ($_instance->childHasBeenRendered('9T4h5hl')) {
    $componentId = $_instance->getRenderedChildComponentId('9T4h5hl');
    $componentTag = $_instance->getRenderedChildComponentTagName('9T4h5hl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9T4h5hl');
} else {
    $response = \Livewire\Livewire::mount('buscador-agregar-items', []);
    $html = $response->html();
    $_instance->logRenderedChild('9T4h5hl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<div class="container mx-auto flex flex-col items-center">
    <img class="object-fill h-[487px] w-[1050px] " src="<?php echo e(asset('img/logo_marca_registrada_page-0001.jpg')); ?>" alt="">
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/auth/detalles_investigador.blade.php ENDPATH**/ ?>