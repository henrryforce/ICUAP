
<?php $__env->startSection('contenido'); ?>
    <div id="relleno-nav"></div>
    <div class="flex justify-center ">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('listar-investigadores', [])->html();
} elseif ($_instance->childHasBeenRendered('RS8n8OX')) {
    $componentId = $_instance->getRenderedChildComponentId('RS8n8OX');
    $componentTag = $_instance->getRenderedChildComponentTagName('RS8n8OX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RS8n8OX');
} else {
    $response = \Livewire\Livewire::mount('listar-investigadores', []);
    $html = $response->html();
    $_instance->logRenderedChild('RS8n8OX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        
    </div>
    
    <div id="relleno"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/listado_investigadores.blade.php ENDPATH**/ ?>