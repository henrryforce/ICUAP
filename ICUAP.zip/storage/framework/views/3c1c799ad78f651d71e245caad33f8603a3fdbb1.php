<div>
    <?php $__currentLoopData = $investigadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investigador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" rounded overflow-hidden shadow-lg">
            <img class="h-[280px] w-auto ml-0" src="<?php echo e(asset('img/logo_cards.png')); ?>" alt="Inserte una imagen">
            <div class="px-6 py-4">
                <div class="font-bold text-xl mb-2"><?php echo e($investigador->nombres); ?> <?php echo e($investigador->apellido_paterno); ?>

                    <?php echo e($investigador->apellido_materno); ?></div>

                <?php $__currentLoopData = $correos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $correo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($correo->id == $investigador->correo_id): ?>
                        <p class="decoration-solid">Correo: <?php echo e($correo->nombre); ?></p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($centro->id == $investigador->centro_adscripcion_id): ?>
                        <p class="decoration-solid">Centro de adscripcion: <?php echo e($centro->nombre); ?></p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="px-6 pt-4 pb-2">
                <?php $__currentLoopData = $areasInteres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $areaInteres): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($areaInteres->investigador_id == $investigador->id): ?>
                        <span
                            class="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">#<?php echo e($areaInteres->nombre); ?></span>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button type="button" wire:click="eliminarInvestigador('<?php echo e($investigador->id); ?>')"
                    class="py-2.5 px-5 ml-2 mb-2 text-sm font-medium text-white focus:outline-none bg-[#b9372d] rounded-full ">Eliminar</button>
                <button type="button" wire:click="editarInvestigador('<?php echo e($investigador->id); ?>','<?php echo e($investigador->nombres); ?>','<?php echo e($investigador->apellido_paterno); ?>','<?php echo e($investigador->apellido_materno); ?>','<?php echo e($investigador->centro_adscripcion_id); ?>','<?php echo e($investigador->correo_id); ?>')"
                    class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-white focus:outline-none bg-[#003B5C] rounded-full "
                    data-bs-toggle="modal" data-bs-target="#editarInvestigador">Editar</button>
            </div>
            <div class="flex justify-end">

            </div>
        </div>
        <div id="relleno"></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div  wire:ignore.self class="modal fade bd-example-modal-lg" id="editarInvestigador" tabindex="-1"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <label for="tipo_user"
                        class="mb-2 block uppercase text-gray-500 font-bold pd:none">Editar usuario</label>
                    <button type="button" data-bs-dismiss="modal" wire:click='resetModal' aria-label="Close">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="w-6 h-6">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Agregar el livewire -->
                    <div class="bg-green-400 text-white my-2 rounded-lg text-sm p2 text-center">
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('message')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <form wire:submit.prevent="submit" method="POST">
                        <div class="mb-2">
                            <label class="mb-2 block uppercase text-gray-500 font-bold">Nombre</label>
                            <input wire:model='nombres' type="text" class="border w-full p-2 rounded-lg ">
                            <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="input-group mb3"> <span
                                        class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2">
                            <label class="mb-2 block uppercase text-gray-500 font-bold">Primer apellido</label>
                            <input wire:model='apellidoPaterno' type="text" class="border w-full p-2 rounded-lg ">
                            <?php $__errorArgs = ['apellidoPaterno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="input-group mb3"> <span
                                        class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2">
                            <label class="mb-2 block uppercase text-gray-500 font-bold">Segundo apellido</label>
                            <input wire:model='apellidoMaterno' type="text" class="border w-full p-2 rounded-lg ">
                            <?php $__errorArgs = ['apellidoMaterno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="input-group mb3"> <span
                                        class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2">
                            <label class="mb-2 block uppercase text-gray-500 font-bold">Correo</label>
                            <input wire:model='correo' type="text" class="border w-full p-2 rounded-lg ">
                            <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="input-group mb3"> <span
                                        class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2">
                            <label class="mb-2 block uppercase text-gray-500 font-bold">Centro de adscripción</label>
                            <select class="form-control" wire:model="centro" id="centroOPt">
                                <option value="0">Selecciona una opcion</option>
                                <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($centro->id); ?>"><?php echo e($centro->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['centro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="input-group mb3"> <span
                                        class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2">
                            <label class="mb-2 block uppercase text-gray-500 font-bold">Area de interes</label>
                            <input wire:model='areas' name="user" type="text"
                                class="border w-full p-2 rounded-lg ">
                            <?php $__errorArgs = ['areas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="input-group mb3"> <span
                                        class="bg-red-500 text-white my-2 rounded-lg text-sm p2 text-center"><?php echo e($message); ?></span>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <input type="submit" id="btnAltaUser" value="Guardar cambios"
                            class="bg-[#003B5C] font-bold w-100 p-3 text-white rounded-lg mt-2" />
                    </form>
                </div><!-- Fin modal body -->
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/listar-investigadores.blade.php ENDPATH**/ ?>