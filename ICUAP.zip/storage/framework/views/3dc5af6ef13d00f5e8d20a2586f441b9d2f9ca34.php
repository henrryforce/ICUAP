
<?php $__env->startSection('contenido'); ?>
    <div id="root">
        <div class="container mx-auto mt-20">
            <h1 class="font-black text-5xl text-center md:w-2/3 mx-auto">Lista usuarios</h1>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('listar-usuarios', [])->html();
} elseif ($_instance->childHasBeenRendered('WGivK0A')) {
    $componentId = $_instance->getRenderedChildComponentId('WGivK0A');
    $componentTag = $_instance->getRenderedChildComponentTagName('WGivK0A');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WGivK0A');
} else {
    $response = \Livewire\Livewire::mount('listar-usuarios', []);
    $html = $response->html();
    $_instance->logRenderedChild('WGivK0A', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            
        </div>
    </div>
    <div id="relleno"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/lista_usuarios.blade.php ENDPATH**/ ?>