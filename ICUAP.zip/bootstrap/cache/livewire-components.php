<?php return array (
  'buscador-agregar-items' => 'App\\Http\\Livewire\\BuscadorAgregarItems',
  'buscador-index' => 'App\\Http\\Livewire\\BuscadorIndex',
  'contacto' => 'App\\Http\\Livewire\\Contacto',
  'listar-investigadores' => 'App\\Http\\Livewire\\ListarInvestigadores',
  'listar-usuarios' => 'App\\Http\\Livewire\\ListarUsuarios',
  'modal-add-user' => 'App\\Http\\Livewire\\ModalAddUser',
  'modal-users-sistema' => 'App\\Http\\Livewire\\ModalUsersSistema',
);