@extends('layouts.app')
@section('contenido')
    <div id="relleno-nav"></div>
    <div class="flex justify-center ">
        <livewire:listar-investigadores />
        
    </div>
    
    <div id="relleno"></div>
@endsection
